
package com.mycompany.lista02.miguel;

public class NumerosImpares {
    public static void main(String[] args) {
        
        for (int i = 0; i <= 90; i++) {
            if (i %2!=0) {
                System.out.println(i);
            }
        }
    }
}
