
package com.mycompany.lista02.miguel;

public class ContadorVariado {
    public static void main(String[] args) {
        Double soma = 0.15;
        for (Double i = 0.15; i < 4.9; ) {
            i = i + soma;
            System.out.println(i); 
        }
    }
}
